

$(document).ready(function() {

    $("form").submit(function() {
        var th = $(this);
        $.ajax({
            type: "POST",
            url: "mail.php",
            data: th.serialize()
        }).done(function() {
            alert("Благодарим за обращение!");
            setTimeout(function() {
                th.trigger("reset");
            }, 1000);
        });
        return false;
    });

});

const validateEmail = (email) => {
    return email.match(
        /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    );
};

const validateMessage = (message) => {
    return message.match(
        " "
    );
};

const validate = () => {
    const $result = $('#result');
    const $result_message = $('#result_message');
    const email = $('#email').val();
    const message = $('#message').val();
    const element = document.getElementById("button");
    $result.text('');
    $result_message.text('');

    if(validateEmail(email)){
        $result.text(email + 'email введен верно.');
        $result.css('display', 'none');
        $result.css('color', 'green');
    } else{
        $result.text(email + ' E-mail введен неверно или не введен.');
        $result.css('display', 'block');
        $result.css('color', 'red');
        element.setAttribute('disabled',"true");
    }
    if(validateMessage(message)){
        $result_message.css('display','none');
        element.removeAttribute('disabled');
    } else{
        $result_message.text('Напишите больше одного слова');
        $result_message.css('display','block');
        element.setAttribute('disabled',"true");
    }
    return false;
}