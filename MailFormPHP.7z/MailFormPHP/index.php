<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>TESTEX</title>
</head>
<body>
<header>
</header>

<div class="container">
    <div class="py-5 text-center">
        <h2><b>Выполнение тестового задания №5</b></h2>
        <p class="lead">Для выполнения работы, были использованы следующие ресурсы: <br> Язык разметки: HTML <br>  Язык программирования: PHP
            <br> Язык программирования: JavaScript <br> Иструмент для создания стилей: Bootstrap/CSS.</p>
    </div>

    <div class="row">
        <div class="col-md-8 order-md-1" id="main">
            <h4 class="mb-3">Заполните форму обращения</h4>

                <form id="form" class="form"  novalidate="">

                    <input type="hidden" name="project_name" value="Kaknazobete">
                    <input type="hidden" name="admin_email" value="example@mail.ru">
                    <input type="hidden" name="form_subject" value="Main Form">

                <div class="mb-3">

                    <label for="email">Email <span class="text-muted"></span></label>
                    <input type="email" onkeyup="validate()" class="form-control" id="email" placeholder="Пример: ivanov@mail.ru" required>
                    <div id="result" class="invalid-feedback">

                    </div>
                </div>

                <div class="mb-3">
                    <label for="text">Текст</label>
                    <div class="form-outline">
                        <textarea onkeyup="validate()" name="message" class="form-control" id="message" rows="4" placeholder="Ваше обращение" required></textarea>
                        <div class="form-notch"><div class="form-notch-leading" style="width: 9px;"></div><div class="form-notch-middle" style="width: 60px;"></div><div class="form-notch-trailing"></div></div></div>
                    <div id="result_message" class="invalid-feedback">
                    </div>
                </div>
                <hr class="mb-4">
                <button id="button" class="btn btn-primary" type="submit">Отправить</button>
            </form>
        </div>
    </div>
</div>
<footer>
    <div class="my-3 p-3 bg-white rounded shadow-sm">
        <h6 class="border-bottom border-gray pb-2 mb-0">Задание выполнил</h6>
        <div class="media text-muted pt-3">
            <svg class="bd-placeholder-img mr-2 rounded" width="32" height="32" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 32x32"><title>Placeholder</title><rect width="100%" height="100%" fill="#6f42c1"></rect><text x="50%" y="50%" fill="#6f42c1" dy=".3em">32x32</text></svg>
            <p class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
                <strong class="d-block text-gray-dark"><a class="link" >Агрызков Александр</a></strong>
                Спасибо, большое, за предоставленное задание! <br> Было очень интересно вспомнить, некоторые детали и изучить много новой информации.
            </p>
        </div>
    </div>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
</body>
</html>