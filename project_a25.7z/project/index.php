<?php
require_once 'backend/sdbh.php';
$dbh = new sdbh();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <link href="assets/css/style.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"  crossorigin="anonymous"></script>

    </head>
    <body>
        <div class="container">
            <div class="row row-header">
                <div class="col-12">
                    <img src="assets/img/logo.png" alt="logo" style="max-height:5em"/>
                    <h1>Прокат</h1>
                </div>
            </div>

            <div class="container">
                <div class="row row-body">
                        <!-- TODO: реализовать форму расчета -->
                    <div class="col-9">
                        <form action="" id="form" method="post">
                            <label class="list-group-item active" for="product">Выберите продукт:</label>
                            <select class="form-select" name="product" id="product">
                                <?
                                $sql = "SELECT * FROM a25_products";
                                $bd = $dbh->query_exc($sql);
                                $null_name = 0;
                                $null_price = 0;
                                $service = $_POST["service_checked"];
                                $price = $_POST["price"];
                                $count = $_POST["count"];
                                $result = $_POST["result"];
                                $auto = $_POST["product"];
                                $tariff = $_POST["price"];
                                $auto_price = 0;
                                $sum_serv = 0;

                                while($row = $bd->fetch_assoc()){ ?>
                                <option value="<?=$row["NAME"]?>"><?=$row["NAME"]?></option>
                                <option value="<?=$row["PRICE"]?>" name="price<?=$row["ID"]?>" hidden></option>
                                <option value="<?=$row["TARIFF"]?>" name="tariff<?=$row["ID"]?>" hidden></option>
                                    <?
                                    if ($row["TARIFF"] == null){
                                        $null_name = $row["NAME"];
                                        $null_price = $row["PRICE"];
                                    }
                                }
                                if ($auto == $null_name) {
                                    $auto_price = $null_price;
                                }
                                else {
                                    $products = unserialize($dbh->mselect_rows('a25_products', ['NAME' => $auto], 0, 1, 'ID')[0]['TARIFF']);
                                    foreach ($products as $n => $s) {
                                        if ($count >= $n) {
                                            $auto_price = $s;
                                        }
                                    }
                                }
                                foreach ($service as $service_checked) {
                                    $sum_serv += $service_checked;
                                }
                                $result = ($auto_price + $sum_serv) * $count;
                                ?>
                            </select>

                            <label for="customRange1" class="list-group-item active">Количество дней:</label>
                            <div class="form-control">
                            <output id="rangevalue">1</output>
                            <input type="range" name="count" class="form-range" id="customRange1" value="1" min="1" max="30" oninput="rangevalue.value=value" style="width: 90%; padding-top: 0.7em">
                            </div>
                            <label for="customRange1" class="list-group-item active">Дополнительные услуги:</label>
                            <div class="list-group">
                            <input class="form-check-input" name="service_checked[]" type="checkbox" value="0" id="ProductChecked_hidden" checked hidden>
                            <?
                            $services = unserialize($dbh->mselect_rows('a25_settings', ['set_key' => 'services'], 0, 1, 'id')[0]['set_value']);
                            foreach($services as $k => $s) { ?>
                                <div class="list-group-item" id="service_container">
                                <input class="form-check-input" name="service_checked[]" type="checkbox" value="<?=$s?>" id="ProductChecked_<?=$k?>" style="border-radius: 4em;">
                                <label class="list-group-item" id="service_item" for="ProductChecked_<?=$k?>">
                                    <?=$k?>: <?=$s?> руб./день
                                </label>
                                </div>
                            <?
                            }
                            ?>
                            </div>
                            <div>
                                <label for="result" class="list-group-item active">Итого:</label>
                                <input type="result" id="disabledTextInput" class="form-control" value="<?=$result?>" disabled>
                                
                            </div>
                            <button type="submit" class="btn btn-primary" style="width: 100%;">Рассчитать</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>